BIRTHDAY SURPRISE WEBSITE

Files:
- index.html
- assets/portrait.jpg

To preview:
Open index.html in a browser.

To publish with GitHub Pages:
1. Upload index.html and the assets folder to the root of your existing birthday-surprise repository.
2. In GitHub: Settings > Pages.
3. Set source to Deploy from a branch, choose main and /(root), then Save.
4. Your existing GitHub Pages address will show the site after deployment.

Still to add:
- Your own voice recording (save as voice-note.mp3)
- Your chosen song (save as song.mp3)
- Your handwritten letter photo (save as assets/letter.jpg)
Then the audio and letter-photo sections can be connected to those files in index.html.
